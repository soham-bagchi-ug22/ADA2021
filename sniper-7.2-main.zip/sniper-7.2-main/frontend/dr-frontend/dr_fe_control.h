#ifndef _DR_FE_CONTROL_H_
#define _DR_FE_CONTROL_H_

#include "dr_fe_control.tcc"

#endif // _DR_FE_CONTROL_H_