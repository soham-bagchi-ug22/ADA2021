#ifndef _DR_FE_THREADS_H_
#define _DR_FE_THREADS_H_

#include "dr_fe_threads.tcc"

#endif // _DR_FE_THREADS_H_