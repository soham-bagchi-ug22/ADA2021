# Sniper-frontend
Frontend for Sniper simulator based on DynamoRIO 
